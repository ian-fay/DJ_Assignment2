package us.ianfay.assignment2.iface;

import us.ianfay.assignment2.Sale;

import java.util.List;

public interface ShippingPolicy {
    void applyShipping(List<Sale> salesList);
}
