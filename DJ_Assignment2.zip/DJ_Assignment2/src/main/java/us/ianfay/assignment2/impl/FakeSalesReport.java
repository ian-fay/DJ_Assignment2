package us.ianfay.assignment2.impl;

import us.ianfay.assignment2.Sale;
import us.ianfay.assignment2.iface.SalesReport;

import java.util.List;

public class FakeSalesReport implements SalesReport {
    @Override
    public void generateReport(List<Sale> salesList) {
        System.out.println("Got a report!");
        for (Sale sale: salesList) {
            System.out.println(sale);
        }
    }
}
