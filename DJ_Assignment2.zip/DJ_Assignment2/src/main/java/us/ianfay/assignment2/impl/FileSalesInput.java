package us.ianfay.assignment2.impl;

import us.ianfay.assignment2.Sale;
import us.ianfay.assignment2.iface.SalesInput;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileSalesInput implements SalesInput {
    @Override
    public List<Sale> getSales() {
        List<Sale> sales = new ArrayList<>();

        File inputFile = new File("sales.txt");

        BufferedReader bufferedReader;
        try {
            bufferedReader = new BufferedReader(new FileReader(inputFile));
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            return sales;
        }

        String line;
        System.out.println("Generating Reports: ");
        do {
            try {
                line = bufferedReader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
                break;
            }
            if(line == null) {
                break;
            }
            //String name, country;
            //double price, tax;

            String[] splitLine = line.split(",", 4);
            System.out.print(".");
            sales.add(new Sale(splitLine[0], splitLine[1], Double.parseDouble(splitLine[2]), Double.parseDouble(splitLine[3])));
        }while (line != null);
        System.out.println("\n"+sales.size()+"sales generated from file at " + inputFile);
        return sales;
    }
}
