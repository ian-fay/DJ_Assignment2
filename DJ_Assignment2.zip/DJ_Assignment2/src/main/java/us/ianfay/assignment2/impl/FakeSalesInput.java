package us.ianfay.assignment2.impl;

import us.ianfay.assignment2.Sale;
import us.ianfay.assignment2.iface.SalesInput;

import java.util.ArrayList;
import java.util.List;

public class FakeSalesInput implements SalesInput {
    @Override
    public List<Sale> getSales() {
        System.out.println("Got a sale!");
        List<Sale> theList = new ArrayList<>();
        theList.add(new Sale("Bob", "America", 4545.01, 22.34));
        theList.add(new Sale("Jeff", "Jeff", 00.00, 00.00));
    return theList;
    }
}
